<h2><?= $title ?></h2>

<p style="color:white" style="text-align: justify"> "It's a pleasure that you visit this blog, enjoy :)" </p>


<p><h1  style="color:skyblue;"> Hi, Welcome to my Blog!! </h1>


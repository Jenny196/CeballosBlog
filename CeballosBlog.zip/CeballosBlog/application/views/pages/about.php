<h2><?= $title ?></h2>

<p>This Blog is more about on how will you showcase your interest, talents and the things that makes what you want the most. </p>

<p>We all know, we have differents lifestyle in life, so that is why here in this blog you can be able to show and might give tips to others. 
Making sure that users feel empowered and gain self connfident very single day. 


<p>In this Blog you can register ang login just clik the word Register buttom and Sign in so that you can be able to post from it for your daily activities.


 <p>It is more a lot of fun if you have a memoeries to share. </p>

